#!/bin/sh
cd /home/k8s/cluster-config/etcd-backup
/snap/bin/juju run-action etcd/0 snapshot keys-version=v3 --wait > /home/k8s/cluster-config/etcd-output
#action="$(awk '{print $5}' /home/k8s/cluster-config/etcd-output1 | sed 's/^.\(.*\).$/\1/' )"
sleep 60
#/snap/bin/juju show-action-output $action > /home/k8s/cluster-config/etcd-output2
dl="$(awk '/cmd:[[:space:]]/ { $1=""; $2=""; print }' /home/k8s/cluster-config/etcd-output)"
bash -c "/snap/bin/juju $dl . "
