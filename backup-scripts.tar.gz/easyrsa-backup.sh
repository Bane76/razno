#!/bin/sh
cd /home/k8s/cluster-config/easyrsa-backup
/snap/bin/juju run-action easyrsa/0 backup --wait > /home/k8s/cluster-config/easyrsa-output
sleep 60
dl="$(awk '/command:[[:space:]]/ { $1=""; $2=""; print }' /home/k8s/cluster-config/easyrsa-output)"
bash -c "/snap/bin/juju $dl . "
