#!/bin/sh
cd /home/k8s/cluster-config/controller-backup
controller="$(juju list-controllers | sed -n '4p' | awk '{print $1}' | sed 's/.$//')"
bash -c "/snap/bin/juju create-backup -m $controller:controller "
